#ifndef __BLUETOOTH_SOURCE_H__
#define __BLUETOOTH_SOURCE_H__

#include <RkBtBase.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* __BLUETOOTH_SOURCE_H__ */
